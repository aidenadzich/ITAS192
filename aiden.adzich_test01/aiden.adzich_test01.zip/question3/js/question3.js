//Made no progress on question 3


// const submit = document.querySelector("#subButton");
// const username = document.querySelector("#username");


// submit.addEventListener("click", validateForm);


// function validateForm() {
//     username.addEventListener("input", validateUsername)
// }

// function validateUsername() {
//     console.log("Username is valid")

// }