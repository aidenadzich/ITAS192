let mountName1 = "Mount Everest";
let mountName2 = "K2";
let mountName3 = "Kangchenjunga";
let mountName4 = "Lhotse";
let mountName5 = "Makalu";

let mountSize1 = 8848;
let mountSize2 = 8611;
let mountSize3 = 8586;
let mountSize4 = 8516;
let mountSize5 = 8485;

console.log(`
    ${mountName1} is ${mountSize1.toLocaleString()} metres high.
    ${mountName2} is ${mountSize2.toLocaleString()} metres high.
    ${mountName3} is ${mountSize3.toLocaleString()} metres high.
    ${mountName4} is ${mountSize4.toLocaleString()} metres high.
    ${mountName5} is ${mountSize5.toLocaleString()} metres high.
    `);